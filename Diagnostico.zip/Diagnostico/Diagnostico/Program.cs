﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Diagnostico
{

    internal class Program
    {
        public int posX;
        public int posY;
        private int dist;
        private int stamina;

        public int Dist
        {
            get { return dist; }
            set { dist = value; }
        }

        public int Stamina
        {
            get { return stamina; }
            set { stamina = value; }
        }

        public class Player
        {

        }

        public class Speedboy : Player
        {
            int dist = 3;
            int stamina = 10;
        }

        public class Energyman : Player
        {
            int dist = 2;
            int stamina = 15;
        }

        static void Main(string[] args)
        {
        }
    }
}
