import turtle as tt

tt.shape("turtle")
tt.speed(0)

def arbol(tam, rep, ang):
    if rep <= 0:
        return
    
    tt.forward(tam)
    tt.right(ang)

    arbol(tam*0.8, rep-1, ang)
    tt.left(ang*2)

    arbol(tam*0.8, rep-1, ang)
    tt.right(ang)
    tt.backward(tam)

def koch_lado(tam, rep, ang):
    if rep <= 0:
        tt.forward(tam)
        return
    
    tam /= 3.0
    koch_lado(tam, rep-1, ang)
    tt.left(ang)
    koch_lado(tam, rep-1, ang)
    tt.right(ang*2)
    koch_lado(tam, rep-1, ang)
    tt.left(ang)
    koch_lado(tam, rep-1, ang)

def koch(tam, rep, ang, lados):
    for i in range(lados):
        koch_lado(tam, rep, ang)
        tt.right(360/lados)

tt.left(90)
arbol(100, 5, 45)
tt.right(90)
koch(100, 3, 60, 5)

tt.mainloop()